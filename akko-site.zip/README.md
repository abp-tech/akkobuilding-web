# AKKO Building Process

Web estática publicada en https://abp-tech.github.io/akkobuilding-web/

## Publicación

GitHub Pages utiliza la rama `main` y la carpeta raíz `/`. El archivo `.nojekyll` permite servir directamente HTML, CSS, JavaScript y los recursos de `v2/`.

Las rutas internas incluyen `/akkobuilding-web/`, necesario para esta dirección de GitHub Pages.

Los formularios son de demostración: no envían mensajes ni documentos. Los contenidos e imágenes señalados como provisionales están pendientes de material definitivo de AKKO.
