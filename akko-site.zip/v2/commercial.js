(()=>{'use strict';
const root=document.querySelector('.page-commercial .projects-swiper');if(!root)return;
root.querySelectorAll('.project-slider__item').forEach(card=>{
 card.addEventListener('focusin',()=>card.dispatchEvent(new Event('mouseenter')));
 card.addEventListener('focusout',()=>card.dispatchEvent(new Event('mouseleave')));
});
})();
