(()=>{'use strict';
const links=[...document.querySelectorAll('[data-service-link]')],rows=[...document.querySelectorAll('.service-row')];
if(!links.length||!rows.length)return;
let scheduled=false;
function update(){scheduled=false;let current=rows[0];for(const row of rows){if(row.getBoundingClientRect().top<=190)current=row;}for(const a of links){if(a.dataset.serviceLink===current.id)a.setAttribute('aria-current','true');else a.removeAttribute('aria-current');}}
function schedule(){if(!scheduled){scheduled=true;requestAnimationFrame(update);}}
addEventListener('scroll',schedule,{passive:true});addEventListener('resize',schedule);update();
})();
