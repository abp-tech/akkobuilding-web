(()=>{'use strict';
const selectors=[...document.querySelectorAll('.language-selector')];
selectors.forEach(selector=>{
 selector.addEventListener('toggle',()=>{selector.querySelector('summary').setAttribute('aria-expanded',String(selector.open));if(selector.open)selectors.filter(s=>s!==selector).forEach(s=>s.open=false)});
 selector.querySelector('[data-current-language]').addEventListener('click',()=>{selector.open=false;selector.querySelector('summary').focus()});
 selector.addEventListener('keydown',e=>{if(e.key==='Escape'){selector.open=false;selector.querySelector('summary').focus()}});
});
document.querySelectorAll('a[role="button"]').forEach(trigger=>{
 trigger.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();trigger.click()}});
 if(trigger.hasAttribute('data-submenu-toggle')){trigger.addEventListener('click',()=>trigger.setAttribute('aria-expanded',trigger.nextElementSibling.getAttribute('aria-expanded')));return}
 const item=trigger.closest('li'),setOpen=value=>{item.classList.toggle('open',value);trigger.setAttribute('aria-expanded',String(value))};
 trigger.addEventListener('click',()=>setOpen(!item.classList.contains('open')));
 item.addEventListener('mouseenter',()=>trigger.setAttribute('aria-expanded','true'));
 item.addEventListener('mouseleave',()=>{if(!item.contains(document.activeElement))setOpen(false)});
 item.addEventListener('focusout',e=>{if(!item.contains(e.relatedTarget))setOpen(false)});
 item.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();setOpen(false);trigger.focus()}if(e.key==='ArrowDown'&&e.target===trigger){e.preventDefault();setOpen(true);item.querySelector('.sub-menu a').focus()}});
});
document.addEventListener('click',e=>selectors.forEach(s=>{if(!s.contains(e.target))s.open=false}));
})();
