/* The project gallery follows document flow; no scroll interception is needed. */
