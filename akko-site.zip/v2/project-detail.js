(()=>{
 'use strict';
 const gallery=document.querySelector('.project-horizontal-gallery');
 if(!gallery)return;
 const viewport=gallery.querySelector('.project-gallery-viewport');
 const track=gallery.querySelector('.project-gallery-track');
 const motion=matchMedia('(prefers-reduced-motion: reduce)');
 let travel=0,pending=false;
 const reduced=()=>motion.matches||document.documentElement.classList.contains('reduce-motion');
 function paint(){
  pending=false;
  if(!gallery.classList.contains('is-pinned'))return;
  const distance=Math.min(travel,Math.max(0,-gallery.getBoundingClientRect().top));
  track.style.transform=`translate3d(${-distance}px,0,0)`;
 }
 function schedule(){if(!pending){pending=true;requestAnimationFrame(paint);}}
 function measure(){
  travel=Math.max(0,track.scrollWidth-viewport.clientWidth);
  const pin=travel>1&&!reduced();
  gallery.style.setProperty('--gallery-travel',`${travel}px`);
  gallery.classList.toggle('is-pinned',pin);
  if(pin)viewport.scrollLeft=0;
  else track.style.removeProperty('transform');
  schedule();
 }
 addEventListener('scroll',schedule,{passive:true});
 addEventListener('resize',measure,{passive:true});
 motion.addEventListener('change',measure);
 new MutationObserver(measure).observe(document.documentElement,{attributes:true,attributeFilter:['class']});
 new ResizeObserver(measure).observe(track);
 track.querySelectorAll('img').forEach(img=>img.addEventListener('load',measure,{once:true}));
 document.fonts.ready.then(measure);
 // Arrow keys match the vertical gesture while this focusable gallery is pinned.
 viewport.addEventListener('keydown',e=>{
  if(!gallery.classList.contains('is-pinned')||!['ArrowLeft','ArrowRight'].includes(e.key))return;
  e.preventDefault();window.scrollBy({top:(e.key==='ArrowRight'?1:-1)*Math.min(innerWidth*.7,600),behavior:'auto'});
 });
 measure();
})();
