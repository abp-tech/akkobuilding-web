(()=>{'use strict';
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
// Three equal vertical rows match Swiper's measured positions; mobile keeps one card per slide.
const el=$('.home-projects-swiper');let carousel;
const reduced=()=>document.documentElement.classList.contains('reduce-motion');
if(el&&window.Swiper){const wrapper=$('.swiper-wrapper',el);[...wrapper.children].forEach(item=>wrapper.append(item.cloneNode(true)));carousel=new Swiper(el,{slidesPerView:1,spaceBetween:10,loop:true,speed:300,autoplay:reduced()?false:{delay:5000,disableOnInteraction:false},breakpoints:{1200:{direction:'vertical',slidesPerView:3,spaceBetween:0}}});document.fonts.ready.then(()=>carousel.update());$$('img',el).forEach(i=>i.addEventListener('load',()=>carousel.update(),{once:true}));new MutationObserver(()=>{if(reduced())carousel.autoplay?.stop();else carousel.autoplay?.start()}).observe(document.documentElement,{attributes:true,attributeFilter:['class']});}
const form=$('.home-contact-form');if(!form)return;
const fields=$('.home-form-fields',form),success=$('.home-form-success',form),input=$('#home-document'),list=$('.home-file-list',form),send=$('#home-send'),upload=$('#home-upload');let attached=[],busy=false;
const controls=$$('.smartplaceholder input,.smartplaceholder textarea',form),result=$('.form-result',form);
form.noValidate=true;
function validate(control){
  const missing=control.required&&!control.value.trim();
  const message=missing?'Este campo es obligatorio.':control.validity.typeMismatch?'Introduce una dirección de email válida.':control.validity.tooLong?'El texto supera la longitud permitida.':'';
  const error=$(`#${control.id}-error`,form);
  error.textContent=message;error.hidden=!message;
  if(message)control.setAttribute('aria-invalid','true');else control.removeAttribute('aria-invalid');
  return !message;
}
controls.forEach(control=>{
  control.id=`home-field-${control.name}`;
  const label=control.closest('label').querySelector(':scope>span:not(.field-error)');
  label.id=`${control.id}-label`;control.setAttribute('aria-labelledby',label.id);
  const error=document.createElement('span');error.className='field-error';error.id=`${control.id}-error`;error.hidden=true;
  control.setAttribute('aria-describedby',error.id);control.after(error);
  control.addEventListener('blur',()=>validate(control));
  control.addEventListener('input',()=>{if(control.hasAttribute('aria-invalid')){validate(control);if(!controls.some(c=>c.hasAttribute('aria-invalid'))){result.textContent='';result.classList.remove('is-error');result.setAttribute('role','status')}}});
});
function validateForm(){
  const invalid=controls.filter(control=>!validate(control));
  result.classList.toggle('is-error',Boolean(invalid.length));
  result.setAttribute('role',invalid.length?'alert':'status');
  result.textContent=invalid.length?'Revisa los campos señalados antes de enviar.':'';
  if(invalid.length)invalid[0].focus();
  return invalid.length===0;
}
function clearErrors(){controls.forEach(control=>{control.removeAttribute('aria-invalid');const error=$(`#${control.id}-error`,form);error.textContent='';error.hidden=true});result.textContent='';result.classList.remove('is-error');result.setAttribute('role','status')}
function renderFiles(){list.replaceChildren();attached.forEach((file,index)=>{const row=document.createElement('div');row.className='home-file-row';const name=document.createElement('span');name.className='filename';name.textContent=file.name;const remove=document.createElement('button');remove.type='button';remove.textContent='Eliminar';remove.setAttribute('aria-label',`Eliminar ${file.name}`);remove.addEventListener('click',()=>{attached.splice(index,1);input.value='';renderFiles()});row.append(name,remove);list.append(row)});upload.querySelector('span').textContent=attached.length?'Añadir documento':'Subir documento';}
upload.addEventListener('click',()=>input.click());input.addEventListener('change',()=>{for(const file of input.files){if(!attached.some(f=>f.name===file.name&&f.size===file.size&&f.lastModified===file.lastModified))attached.push(file)}renderFiles()});
form.addEventListener('submit',e=>{e.preventDefault();if(busy||!validateForm())return;busy=true;form.classList.add('is-submitting');send.disabled=true;upload.disabled=true;send.querySelector('span').textContent='Procesando…';form.setAttribute('aria-busy','true');setTimeout(()=>{form.reset();clearErrors();attached=[];renderFiles();$$('.filled',form).forEach(l=>l.classList.remove('filled'));fields.hidden=true;success.hidden=false;form.classList.remove('is-submitting');form.removeAttribute('aria-busy');busy=false;send.disabled=false;upload.disabled=false;send.querySelector('span').textContent='Enviar';success.focus({preventScroll:true});},reduced()?0:500)});
$('#home-send-again').addEventListener('click',()=>{success.hidden=true;fields.hidden=false;$('input[name=first]',form).focus({preventScroll:true})});
})();
