(()=>{
 const button=document.querySelector('[data-share-article]');
 if(!button)return;
 button.addEventListener('click',async()=>{
  const result=document.querySelector('.share-result');
  const url=new URL(location.href);url.hash='';
  try{await navigator.clipboard.writeText(url.href);result.textContent='Enlace copiado. Ya puedes compartir el artículo.';}
  catch{const field=document.querySelector('.share-url');field.hidden=false;field.value=url.href;field.focus();field.select();result.textContent='Copia este enlace para compartir el artículo.';}
 });
})();

/* Local category filtering mirrors the reference journal navigation. */
(()=>{
 const grid=document.querySelector('#news-results');if(!grid)return;
 const nav=document.querySelector('.change-post-category');if(!nav)return;
 const buttons=[...nav.querySelectorAll('button[data-news-category]')];
 const cards=[...grid.children];const status=document.querySelector('.news-filter-status');
 buttons.forEach(button=>button.addEventListener('click',()=>{
  const category=button.dataset.newsCategory;
  buttons.forEach(item=>{const selected=item===button;item.setAttribute('aria-pressed',String(selected));item.closest('li').classList.toggle('current',selected);});
  let count=0;cards.forEach(card=>{const visible=category==='*'||card.dataset.newsCategory===category;card.hidden=!visible;if(visible){count++;card.classList.add('in-viewport');}});
  if(status)status.textContent=`${count} ${count===1?'noticia':'noticias'}${category==='*'?' en total':` de ${category}`}.`;
 }));
})();
