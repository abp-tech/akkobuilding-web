(()=>{
 const button=document.querySelector('[data-share-article]');
 if(!button)return;
 button.addEventListener('click',async()=>{
  const result=document.querySelector('.share-result');
  const url=new URL(location.href);url.hash='';
  try{await navigator.clipboard.writeText(url.href);result.textContent='Enlace copiado. Ya puedes compartir el artículo.';}
  catch{const field=document.querySelector('.share-url');field.hidden=false;field.value=url.href;field.focus();field.select();result.textContent='Copia este enlace para compartir el artículo.';}
 });
})();
