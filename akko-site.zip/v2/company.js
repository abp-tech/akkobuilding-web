/* Company journal cards use the reference's native, content-sized list layout. */
