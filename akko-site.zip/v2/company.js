(()=>{'use strict';
const el=document.querySelector('.company-news-swiper');if(!el||!window.Swiper)return;
const wrapper=el.querySelector('.swiper-wrapper');[...wrapper.children].forEach(slide=>wrapper.append(slide.cloneNode(true)));
const reduced=()=>document.documentElement.classList.contains('reduce-motion');
const carousel=new Swiper(el,{slidesPerView:1,spaceBetween:16,loop:true,speed:300,autoplay:reduced()?false:{delay:5000,disableOnInteraction:false,pauseOnMouseEnter:true},breakpoints:{990:{direction:'vertical',slidesPerView:3,spaceBetween:0}}});
document.fonts.ready.then(()=>carousel.update());el.querySelectorAll('img').forEach(img=>img.addEventListener('load',()=>carousel.update(),{once:true}));
new MutationObserver(()=>{if(reduced())carousel.autoplay?.stop();else carousel.autoplay?.start()}).observe(document.documentElement,{attributes:true,attributeFilter:['class']});
})();
