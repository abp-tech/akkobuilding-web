(()=>{'use strict';
const el=document.querySelector('.company-news-swiper');if(!el||!window.Swiper)return;
const wrapper=el.querySelector('.swiper-wrapper');[...wrapper.children].forEach(slide=>wrapper.append(slide.cloneNode(true)));
const reduced=()=>document.documentElement.classList.contains('reduce-motion');
const carousel=new Swiper(el,{slidesPerView:1,spaceBetween:16,loop:true,speed:300,autoplay:reduced()?false:{delay:5000,disableOnInteraction:false,pauseOnMouseEnter:true},breakpoints:{990:{direction:'vertical',slidesPerView:3,spaceBetween:0}}});
let pending=false;
function measure(){
 pending=false;
 if(innerWidth>=990){
  const height=Math.ceil(Math.max(...[...el.querySelectorAll('.journal-card')].map(card=>card.getBoundingClientRect().height)));
  if(height>0)el.style.setProperty('--journal-row-height',`${height}px`);
 }else el.style.removeProperty('--journal-row-height');
 carousel.update();
}
function schedule(){if(!pending){pending=true;requestAnimationFrame(measure);}}
// Three complete cards remain visible; each row accommodates its image, date and excerpt.
document.fonts.ready.then(schedule);
el.querySelectorAll('img').forEach(img=>img.addEventListener('load',schedule,{once:true}));
addEventListener('resize',schedule,{passive:true});
measure();
new MutationObserver(()=>{if(reduced())carousel.autoplay?.stop();else carousel.autoplay?.start()}).observe(document.documentElement,{attributes:true,attributeFilter:['class']});
})();
