(()=>{'use strict';
const data=document.querySelector('#career-openings'),list=document.querySelector('#career-openings-list'),template=document.querySelector('#career-opening-template');
if(!data||!list||!template)return;
let openings;try{openings=JSON.parse(data.textContent)}catch{return}
if(!Array.isArray(openings))return;
const cards=[];
for(const opening of openings){
 if(!opening.title||!opening.description)continue;
 let url;try{url=new URL(opening.url||template.content.querySelector('a').href)}catch{continue}
 if(url.protocol!=='https:')continue;
 const card=template.content.cloneNode(true);
 card.querySelector('h3').textContent=opening.title;
 card.querySelector('p').textContent=opening.description;
 card.querySelector('a').href=url.href;
 cards.push(card);
}
if(cards.length)list.replaceChildren(...cards);
})();
