(()=>{'use strict';
const gallery=document.querySelector('#project-gallery');if(!gallery)return;
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const data=JSON.parse($('#project-data').textContent),results=$('#project-results'),templates=[...results.children].map(el=>el.outerHTML);
let sector=new URLSearchParams(location.search).get('sector')||'*',timer;
if(sector==='Hoteleros')sector='Hoteles';
if(sector!=='*'&&!data.some(p=>p.sector===sector))sector='*';
const reduced=()=>document.documentElement.classList.contains('reduce-motion');
function render(updateUrl=false){
 clearTimeout(timer);gallery.classList.add('loading');gallery.setAttribute('aria-busy','true');gallery.classList.toggle('is-sector-filtered',sector!=='*');
 $$('[data-sector]').forEach(b=>{const active=b.dataset.sector===sector;b.setAttribute('aria-pressed',String(active));b.closest('li').classList.toggle('current',active)});
 if(updateUrl){const url=new URL(location.href);if(sector==='*')url.searchParams.delete('sector');else url.searchParams.set('sector',sector);history.replaceState(null,'',url.pathname+url.search+url.hash)}
 timer=setTimeout(()=>{const cards=data.flatMap((p,i)=>sector==='*'||p.sector===sector?[templates[i]]:[]);results.innerHTML=cards.join('')||'<li><p>No hay proyectos para este sector.</p></li>';gallery.classList.remove('loading');gallery.removeAttribute('aria-busy')},reduced()?0:300);
}
$$('[data-sector]').forEach(b=>b.addEventListener('click',()=>{sector=b.dataset.sector;render(true)}));
$$('[data-view]').forEach(b=>b.addEventListener('click',()=>{gallery.dataset.style=b.dataset.view;$$('[data-view]').forEach(v=>v.setAttribute('aria-pressed',String(v===b)))}));
function preview(a){$$('.project-card-preview-image>a',gallery).forEach(p=>p.classList.toggle('active',p.getAttribute('href')===a?.getAttribute('href')))}
results.addEventListener('mouseover',e=>preview(e.target.closest('a')));results.addEventListener('focusin',e=>preview(e.target.closest('a')));results.addEventListener('mouseleave',()=>preview(null));results.addEventListener('focusout',e=>{if(!results.contains(e.relatedTarget))preview(null)});
render();
})();
