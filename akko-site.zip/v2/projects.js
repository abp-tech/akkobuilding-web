(()=>{'use strict';
const gallery=document.querySelector('#project-gallery');if(!gallery)return;
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const data=JSON.parse($('#project-data').textContent),results=$('#project-results'),templates=[...results.children].map(el=>el.outerHTML);
const collator=new Intl.Collator('es',{sensitivity:'base',numeric:true});
let sector=new URLSearchParams(location.search).get('sector')||'*',timer,sortKey=null,direction=1;
if(sector==='Hoteleros')sector='Hoteles';
if(sector!=='*'&&!data.some(p=>p.sector===sector))sector='*';
const reduced=()=>document.documentElement.classList.contains('reduce-motion');
function year(value){const match=String(value||'').match(/\b\d{4}\b/);return match?Number(match[0]):null;}
function ordered(){
 const rows=data.map((p,i)=>({p,i})).filter(({p})=>sector==='*'||p.sector===sector);
 if(!sortKey)return rows;
 return rows.sort((a,b)=>{
  const av=sortKey==='year'?year(a.p.year):a.p.place?.trim()||null;
  const bv=sortKey==='year'?year(b.p.year):b.p.place?.trim()||null;
  // Missing values stay last in either direction; ties retain the editorial order.
  if(av===null||bv===null)return av===bv?a.i-b.i:av===null?1:-1;
  return direction*(sortKey==='year'?av-bv:collator.compare(av,bv))||a.i-b.i;
 });
}
function preview(a){
 if(!a)return;
 $$('.project-card-preview-image>a',gallery).forEach(p=>p.classList.toggle('active',p.getAttribute('href')===a.getAttribute('href')));
}
function render(updateUrl=false,announce=false){
 clearTimeout(timer);gallery.classList.add('loading');gallery.setAttribute('aria-busy','true');gallery.classList.toggle('is-sector-filtered',sector!=='*');
 $$('[data-sector]').forEach(b=>{const active=b.dataset.sector===sector;b.setAttribute('aria-pressed',String(active));b.closest('li').classList.toggle('current',active)});
 $$('[data-sort]').forEach(b=>{
  const active=b.dataset.sort===sortKey;
  b.setAttribute('aria-pressed',String(active));b.dataset.direction=active?(direction===1?'ascending':'descending'):'none';
  const label=b.dataset.sort==='year'?'Año':'Ubicación';
  const nextDirection=active?-direction:1;
  const action=b.dataset.sort==='year'?(nextDirection===1?'del más antiguo al más reciente':'del más reciente al más antiguo'):(nextDirection===1?'de A a Z':'de Z a A');
  b.setAttribute('aria-label',`${label}: ordenar ${action}`);
 });
 if(updateUrl){const url=new URL(location.href);if(sector==='*')url.searchParams.delete('sector');else url.searchParams.set('sector',sector);history.replaceState(null,'',url.pathname+url.search+url.hash)}
 timer=setTimeout(()=>{
  const rows=ordered();results.innerHTML=rows.map(({i})=>templates[i]).join('')||'<li><p>No hay proyectos para este sector.</p></li>';
  preview(results.querySelector('.list-details'));gallery.classList.remove('loading');gallery.removeAttribute('aria-busy');
  if(announce)$('#project-sort-status').textContent=`Ordenado por ${sortKey==='year'?'año':'ubicación'}, ${direction===1?'ascendente':'descendente'}. Los datos pendientes aparecen al final.`;
 },reduced()?0:300);
}
$$('[data-sector]').forEach(b=>b.addEventListener('click',()=>renderSector(b.dataset.sector)));
function renderSector(value){sector=value;render(true);}
$$('[data-sort]').forEach(b=>b.addEventListener('click',()=>{direction=sortKey===b.dataset.sort?-direction:1;sortKey=b.dataset.sort;render(false,true)}));
$$('[data-view]').forEach(b=>b.addEventListener('click',()=>{gallery.dataset.style=b.dataset.view;$$('[data-view]').forEach(v=>v.setAttribute('aria-pressed',String(v===b)));if(b.dataset.view==='list-style')preview(results.querySelector('.list-details'))}));
results.addEventListener('mouseover',e=>preview(e.target.closest('a')));
results.addEventListener('focusin',e=>preview(e.target.closest('a')));
render();
})();
