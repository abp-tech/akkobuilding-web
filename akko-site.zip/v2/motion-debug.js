/* Opt-in, browser-local diagnostics. No requests, storage, tracking or personal form values. */
(()=>{'use strict';
if(new URLSearchParams(location.search).get('diagnostico')!=='1')return;
const errors=[];
addEventListener('error',event=>{
 const resource=event.target!==window?event.target.getAttribute?.('src')||event.target.getAttribute?.('href'):null;
 errors.push(resource?'Recurso no cargado: '+resource:(event.message||'Error de JavaScript')+' · línea '+(event.lineno||'?'));
},true);
addEventListener('unhandledrejection',event=>errors.push('Error asíncrono: '+String(event.reason?.message||event.reason)));
const panel=document.createElement('aside');panel.id='motion-debug';panel.setAttribute('aria-label','Comprobación de animaciones');
const details=document.createElement('details');details.open=true;
const summary=document.createElement('summary');summary.textContent='Comprobación de animaciones';
const note=document.createElement('p');note.textContent='Solo se muestra en este navegador. No envía datos ni cambia los ajustes del teléfono.';
const report=document.createElement('textarea');report.readOnly=true;report.setAttribute('aria-label','Informe de animaciones');report.rows=8;
const actions=document.createElement('div');actions.className='motion-debug-actions';
for(const [label,mode] of [['Probar animaciones','completo'],['Usar ajuste del dispositivo','sistema']]){
 const a=document.createElement('a'),url=new URL(location.href);url.hash='';
 if(mode==='sistema')url.searchParams.delete('movimiento');else url.searchParams.set('movimiento',mode);
 a.href=url.href;a.textContent=label;actions.append(a);
}
const copy=document.createElement('button');copy.type='button';copy.textContent='Copiar informe';
copy.addEventListener('click',async()=>{
 report.focus();report.select();
 try{await navigator.clipboard.writeText(report.value);copy.textContent='Informe copiado';}
 catch{copy.textContent='Mantén pulsado el informe para copiarlo';}
});actions.append(copy);
details.append(summary,note,report,actions);panel.append(details);document.body.append(panel);
function refresh(){
 const html=document.documentElement,loader=document.querySelector('.preloader'),words=document.querySelectorAll('.animated-intro .word');
 const fade=document.querySelector('.fadeinandslideup'),missing=[...document.images].filter(img=>img.complete&&!img.naturalWidth).length;
 report.value=[
  'AKKO · diagnóstico movimiento 1',
  'Página: '+location.pathname,
  'Navegador pide reducir movimiento: '+(matchMedia('(prefers-reduced-motion: reduce)').matches?'SÍ':'NO'),
  'Modo solicitado: '+(html.dataset.motionMode||'motor pendiente'),
  'Motor iniciado: '+(html.dataset.motionReady==='true'?'SÍ':'NO'),
  'Movimiento reducido aplicado: '+(html.classList.contains('reduce-motion')?'SÍ':'NO'),
  'Carga inicial: '+(!loader?'no hay en esta página':loader.hidden?'terminada':'visible'),
  'Palabras preparadas: '+words.length,
  'Transición de entrada: '+(fade?getComputedStyle(fade).transitionDuration:'sin elemento'),
  'Imágenes sin cargar: '+missing,
  'Errores: '+(errors.length?errors.join(' | '):'ninguno detectado')
 ].join('\n');
}
refresh();addEventListener('load',refresh);addEventListener('pageshow',refresh);
const timer=setInterval(refresh,1000);setTimeout(()=>{clearInterval(timer);refresh()},15000);
})();
